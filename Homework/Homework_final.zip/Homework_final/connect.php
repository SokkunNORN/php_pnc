
<?php

$servername = "localhost";
$username = "root";
$pass = "";
$dbname = "tbl_teacher";

$conn = mysqli_connect($servername, $username, $pass, $dbname);



