

<?php
$sName = 'localhost';
$uName = 'root';
$pass = '';
$dbName = 'final_exam';

$conn = mysqli_connect($sName, $uName, $pass, $dbName);


