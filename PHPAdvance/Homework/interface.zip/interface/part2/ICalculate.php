
<?php

interface ICalculate {
    public function totalMoney();
    public function moneyPayment();
    public function totalInterest();
}


