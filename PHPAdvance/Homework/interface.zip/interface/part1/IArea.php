
<?php

interface IArea {
    public function square($corner1, $corner2);
    public function rectangular($long, $width);
    public function circle($r);
}


