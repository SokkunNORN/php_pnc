
<?php

namespace sokkun\Repositories;

class UserRepository 
{
    public function __construct()
    {
        echo "this is repository.";
    }
}




