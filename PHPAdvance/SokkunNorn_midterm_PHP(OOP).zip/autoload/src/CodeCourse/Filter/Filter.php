
<?php

namespace sokkun\Filter;

class Filter
{
    public function __construct()
    {
        echo "this is filter.";
    }
}