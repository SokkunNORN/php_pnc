
<?php

use sokkun\Repositories\UserRepository;
use sokkun\Filter\Filter;
require "vendor/autoload.php";

$sokkun = new UserRepository();
$lala = new Filter();

