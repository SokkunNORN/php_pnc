<?php
$con = mysqli_connect('localhost','root','','oop_autoload');

?>