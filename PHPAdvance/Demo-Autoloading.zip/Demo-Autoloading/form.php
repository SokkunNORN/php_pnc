<div class="container mt-4">
    <div class="row">
        <div class="col-3"> </div>
        <div class="col-6">
            <div class="card">
                <div class="card-header">Create New</div>
                <div class="card-body">
                <form action="getdata.php" method='post'>
                    <div class="form-group">
                        <input type="text" name='name' class='form-control' placeholder='name'>
                    </div>
                    <div class="form-group form-check">
                        <input type="radio" name='gender' value="Male" id='male'><label for="male">Male</label>
                        <input type="radio" name='gender' value="Female" id='female'><label for="female">Female</label>
                    </div>
                    <button type='submit' name='save' class='btn btn-info float-right'>Save</button>

                </form>
                </div>
            </div>
               
        </div>
       <div class="col-3"></div>
    </div>
</div>