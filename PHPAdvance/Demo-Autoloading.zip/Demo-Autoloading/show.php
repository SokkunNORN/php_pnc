<div class="container mt-4  ">
<table class=" table table-bordered-table-striped">
   <thead class="bg-dark">
       <tr>
           <th>ID</th>
           <th>Name</th>
           <th>Gender</th>
       </tr>
   </thead>
   <?php
   include "connection.php";
   $query ="SELECT * FROM tblstudent";
   $result = mysqli_query($con,$query);
   foreach ($result as $value):
   ?>
   <tbody>
       <tr>
           <td><?php echo $value['id'] ;?></td>
           <td><?php echo $value['name'] ;?></td>
           <td><?php echo $value['gender'] ;?></td>
       </tr>
   </tbody>
   <?php
   endforeach;
   ?>
</table>
</div>
