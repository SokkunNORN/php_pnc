<?php
include "connection.php";
// include "src/insertData.php";
include 'vendor/autoload.php';
use CodeCourse\insertData;
if(isset($_POST['save'])){
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $student = new insertData($name,$gender);
    $getName = $student->getName();
    $getGender = $student->getGender();
    $query= "INSERT INTO tblstudent(name,gender)
     values('$getName','$getGender')";
     $result = mysqli_query($con,$query);
    if($result) {
       header('location:index.php');
    }
    else{
        echo "can't";
    }
}