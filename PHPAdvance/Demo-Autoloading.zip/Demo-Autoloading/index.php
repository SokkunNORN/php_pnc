<?php
include "header.php";
include "form.php";
include "show.php";
include "footer.php";